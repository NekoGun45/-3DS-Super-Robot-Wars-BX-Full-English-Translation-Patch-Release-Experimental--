# -*- coding: utf-8 -*-
"""
Applies the Super Robot Wars BX English patches and builds a ready-to-use
Citra mod folder.

Usage:
    python apply_patches.py <romfs_folder> <code_original.bin>

  <romfs_folder>       folder from Citra's "Dump RomFS" (must contain
                       arcTacPrmDat.bin, arcCmnPrmDat.bin, arcBtlPrmDat.bin
                       and arcBtlMsgDat.bin)
  <code_original.bin>  output of tools/extract_code.py

Needs xdelta3 (https://github.com/jmacd/xdelta-gpl/releases): either on your
PATH, or xdelta3.exe placed next to this script.

Output: a folder "0004000000127900" next to this script, with the patched
code.bin and romfs/ inside. Copy that folder into Citra's mods location.
Your original files are never modified.
"""
import hashlib, os, shutil, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
PATCHES = os.path.join(HERE, "..", "patches")
OUT = os.path.join(HERE, "0004000000127900")

# file: (original MD5, patched MD5)
FILES = {
    "arcTacPrmDat.bin": ("7093ef37be2ab87166a3e740e05b55ab", "fa356266a045d213e354caccfa005176"),
    "arcCmnPrmDat.bin": ("3ef0458a81c311147bbe7957d69e0b74", "35e84a3bed98e3c20017288ad6c36284"),
    "arcBtlPrmDat.bin": ("1e40a8ee87ae71f02e136383da4508be", "36e1bb79ce6068804ecf807186a0d673"),
    "arcBtlMsgDat.bin": ("ba354eecb8747b758d069a8e2ed0556b", "69ca818d91eb440a7935e4edd977aff1"),
}
CODE = ("b9f2ff6be2f089e528fb28e74568e613", "c1329ba93dee8a38f15271b25fed4d0f")


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def find_xdelta():
    for name in ("xdelta3.exe", "xdelta3", "xdelta.exe"):
        local = os.path.join(HERE, name)
        if os.path.isfile(local):
            return local
    found = shutil.which("xdelta3") or shutil.which("xdelta")
    if found:
        return found
    sys.exit("xdelta3 not found. Put xdelta3.exe next to this script or add it to your PATH.")


def patch(xd, src, delta, dst, expected_src, expected_dst, label):
    got = md5(src)
    if got != expected_src:
        sys.exit(f"{label}: your original file doesn't match (MD5 {got}).\n"
                 f"Expected {expected_src}. Make sure it comes from an unmodified Japanese ROM.")
    subprocess.run([xd, "-d", "-f", "-B", "134217728", "-s", src, delta, dst], check=True)
    got = md5(dst)
    if got != expected_dst:
        sys.exit(f"{label}: patched file has the wrong MD5 ({got}). Something went wrong.")
    print(f"  {label}: OK")


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    romfs, code = sys.argv[1], sys.argv[2]
    xd = find_xdelta()
    os.makedirs(os.path.join(OUT, "romfs"), exist_ok=True)
    print("Patching...")
    for name, (a, b) in FILES.items():
        src = os.path.join(romfs, name)
        if not os.path.isfile(src):
            sys.exit(f"Missing {src}")
        delta = os.path.join(PATCHES, name.replace(".bin", ".xdelta"))
        patch(xd, src, delta, os.path.join(OUT, "romfs", name), a, b, name)
    patch(xd, code, os.path.join(PATCHES, "code.xdelta"), os.path.join(OUT, "code.bin"),
          CODE[0], CODE[1], "code.bin")
    print(f"\nDone. Copy this folder into Citra's mods location:\n  {OUT}")


if __name__ == "__main__":
    main()
